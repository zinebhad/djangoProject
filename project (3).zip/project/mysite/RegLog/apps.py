from django.apps import AppConfig


class ReglogConfig(AppConfig):
    name = 'RegLog'
