from django.contrib import admin
from .models import Restaurants,ImageDetails,Comment


# Register your models here.
admin.site.register(Restaurants)
admin.site.register(ImageDetails)
admin.site.register(Comment)
class ImageDetailInline(admin.TabularInline):
	model=ImageDetails

class Restaurant(admin.ModelAdmin):
	inlines=[ImageDetailInline]