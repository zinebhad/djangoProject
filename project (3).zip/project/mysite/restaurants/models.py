from django.db import models
from django.contrib.auth.models import User
from django.forms import ModelForm
from django.utils.safestring import mark_safe
from mptt.fields import TreeForeignKey
from django.db.models import Avg, Count

# Create your models here.
 
class Restaurants(models.Model):
    name = models.CharField('Restaurant Name', max_length=120)
    avatar=models.ImageField(upload_to='media',max_length=255,null=True,blank=True)
    typeCuisine=models.CharField('Type Cuisine',max_length=255,null=True,blank=True)
    Repas=models.CharField('Repas',max_length=50,null=True,blank=True)
    fonctionnalité=models.CharField('fonctionnalite',max_length=255,null=True,blank=True)
    address=models.CharField('Restaurant Address',max_length=255,null=True,blank=True)
    latitude=models.FloatField(null=True)
    longitude=models.FloatField(null=True)

    def avaregereview(self):
        reviews = Comment.objects.filter(restaurant=self).aggregate(avarage=Avg('rate'))
        avg=0
        if reviews["avarage"] is not None:
            avg=float(reviews["avarage"])
        return avg

    def countreview(self):
        reviews = Comment.objects.filter(restaurant=self).aggregate(count=Count('id'))
        cnt=0
        if reviews["count"] is not None:
            cnt = int(reviews["count"])
        return cnt

class ImageDetails(models.Model):
	rest=models.ForeignKey('Restaurants',on_delete=models.CASCADE,related_name='image');
	pictures=models.ImageField(upload_to='media/images')

class Comment(models.Model):
    restaurant=models.ForeignKey(Restaurants,on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.CharField(max_length=250,blank=True)
    rate = models.IntegerField(default=1)
    ip = models.CharField(max_length=20, blank=True)
    create_at=models.DateTimeField(auto_now_add=True)
    update_at=models.DateTimeField(auto_now=True)
    


class CommentForm(ModelForm):
    class Meta:
        model = Comment
        fields = ['comment', 'rate']