from django.shortcuts import render
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from .models import Restaurants,ImageDetails,Comment,CommentForm
from RegLog.models import Profile
from geopy import Nominatim
from django.views import generic
import folium

# Create your views here.

def detail(request,id):
	rest=Restaurants.objects.get(id=id)
	current_user = request.user
	context={'images':ImageDetails.objects.all(),'rest':rest,'comments':Comment.objects.filter(restaurant_id=id)
}
	return render(request,'restaurants/detail.html',context)





def restaurants_list(request):
	restList=Restaurants.objects.all()
	query=request.GET.get("q")
	if query:
		restList=restList.filter(name__icontains=query)
	current_user=request.user
	context={'restaurants':restList,'comments':Comment.objects.all(),'add':Profile.objects.filter(user_id=current_user.id)}
	return render(request, 'restaurants/index.html', context)





def testMap(request):

    context={}
    geolocator = Nominatim(user_agent="AjoutRes")
    test=AjoutRes.objects.all()
    r = test[0:]
    add_l=[]
    print(test)
    m = folium.Map(width=500,height=500,location=[40, -99], zoom_start=4)
    try:
        add_l = []
        for x in r:
            add_no = x.nom
            add_c = x.ville
            idt = x.id
            adresse = x.adresse
            loc = geolocator.geocode(add_no+", "+str(x.ville)+", Maroc")
            add_l.append(loc)
            #x.latitude = loc.latitude
            #x.longitude = loc.

            AjoutRes.objects.filter(id=x.id).update(latitude=loc.latitude,longitude=loc.longitude)
            
            #add_l={'loc':loc,'id':idt}
            #add_l = {'loc':loc,'id':x.id}
        #for t in add_l:
            #folium.Marker(location=[t.latitude,t.longitude]).add_to(m)
        #df = pd.DataFrame(list(AjoutRes.objects.all().value()))

        context={'m':m,'list':add_l,'r':r,'test':test}
    except Exception:
        print("Erreur")
    #for ts in AjoutRes.objects.all():
        #context={'location':(geolocator.geocode(ts.nom))}
        #context={'lat':loc.latitude,'lon':loc.longitude}
    #location = geolocator.geocode("Boulevard Hassan 2, Agadir 30000 Maroc")
    #print(location.address)
    #context={'lat':location.latitude,'lon':location.longitude,'ad':AjoutRes.objects.all()}
    #m.save('AjoutRes/testMap.html')
    #m.get_root().render()
    #m.repr_html()
    return render(request,'blog/testMap.html',context)
    #return render(request,'AjoutRes/testMap.html',context)

def home(response):
   context={}
   geolocator = Nominatim(user_agent="Restaurants")
   test=Restaurants.objects.all()
   m = folium.Map(width=500,height=500,location=[40, -99], zoom_start=4)
   context={'m':m,'test':test}
          
   return render(response,"restaurants/map.html",context)


def addcomment(request,id):
   url = request.META.get('HTTP_REFERER')  # get last url
   #return HttpResponse(url)
   if request.method == 'POST':  # check post
      form = CommentForm(request.POST)
      if form.is_valid():
         data = Comment()  # create relation with model
         data.comment = form.cleaned_data['comment']
         data.rate = form.cleaned_data['rate']
         data.ip = request.META.get('REMOTE_ADDR')
         data.restaurant_id=id
         current_user= request.user
         data.user_id=current_user.id
         data.save()  # save data to table
         messages.success(request, "Your review has ben sent. Thank you for your interest.")
         return HttpResponseRedirect(url)

   return HttpResponseRedirect(url)
